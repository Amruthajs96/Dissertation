# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 12:09:20 2024

@author: amrut
"""

#%%
# Import the package
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.model_selection import train_test_split

# Replace 'file_path' with the path to your CSV file 
file_path = r'C:/Users/aj01421/Downloads/Taiwan.xlsx'# Read the Excel file into a DataFrame
Raw_DataFrame = pd.read_excel(file_path)
#%%
# Display/check the attribute names of the dataframe
print('\n\n\n-----------------------------------------------------------------------')
print('Attribute Names of the Dataframe')
print('-----------------------------------------------------------------------')
print(Raw_DataFrame.columns)
print('----------------------------------------------------------------------- \n\n\n')
#%%
#Display the types and information about data
print('----------------------------------------------------------------------------')
print('Types and Information about DataFrame')
print('----------------------------------------------------------------------------')
print(Raw_DataFrame.info())
print('---------------------------------------------------------------------------- \n\n\n')
#%%
# ----------------------------
# Data Dimension
# ----------------------------

# Shape of the Data
DataFrame_Shape = Raw_DataFrame.shape
# Number of row
DataFrame_Row = DataFrame_Shape[0]
# Number of column
DataFrame_Col = DataFrame_Shape[1]
#%%
# ---------------------------
# One-Hot Encoding of Categorical Data
# ---------------------------

# Shape of the Data
DataFrame_Shape = Raw_DataFrame.shape
# Number of rows
DataFrame_Row = DataFrame_Shape[0]
# Number of columns
DataFrame_Col = DataFrame_Shape[1]

# Initialize an empty DataFrame for numeric and one-hot encoded data
Numeric_DataFrame = pd.DataFrame()

for Attribute in Raw_DataFrame.columns:
    if pd.api.types.is_numeric_dtype(Raw_DataFrame[Attribute]):
        print("-----------------------------------------------------------------------------------")
        print("Data type of attribute - " + Attribute + " - is numeric, no conversion required")
        Numeric_DataFrame[Attribute] = Raw_DataFrame[Attribute]
    else:
        print("-----------------------------------------------------------------------------------")
        print("Data type of attribute - " + Attribute + " - is not numeric, conversion required")
        # Apply one-hot encoding to this attribute and concatenate with the numeric dataframe
        one_hot_encoded_df = pd.get_dummies(Raw_DataFrame[Attribute], prefix=Attribute)
        Numeric_DataFrame = pd.concat([Numeric_DataFrame, one_hot_encoded_df], axis=1)
        print("\tData type of attribute - " + Attribute + " - is now one-hot encoded")

#%%
# ----------------------------------------
# Missing value identification
# ----------------------------------------

# Missing Values Calculation
ms = Numeric_DataFrame.isnull().sum()
# Calculate the percentage of missing values in each column
ms_percentage = (Numeric_DataFrame.isnull().sum()/(len(Numeric_DataFrame)))*100
# Combine the missing value information into one dataframe 
Missing_Data_Info = pd.DataFrame({'Total Missings': ms, 'Percentage': ms_percentage})
# Print them the missing value information on screen
print('----------------------------------------')
print('Missing Data Information')
print('----------------------------------------')
print(Missing_Data_Info)
print('----------------------------------------\n\n\n')
#%%
# -------------------
# Data Statistics 
# -------------------

# Assuming Raw_DataFrame is already defined
Data_Stat = Numeric_DataFrame.describe().T

# Calculate additional statistics
Data_Stat['median'] = Numeric_DataFrame.median()
Data_Stat['mode'] = Numeric_DataFrame.mode().iloc[0]  # Taking the first mode
Data_Stat['std'] = Numeric_DataFrame.std()

# Display the updated statistics summary
print('-------------------------------------------------------------------------------')
print('Data Summary')
print('-------------------------------------------------------------------------------')
print(Data_Stat)
print('-------------------------------------------------------------------------------\n\n\n')

# To include all data types including objects, categories, etc.
Data_Stat_All = Numeric_DataFrame.describe(include='all').T

# Calculate additional statistics for all data types
# Handle numeric statistics separately
numeric_cols = Numeric_DataFrame.select_dtypes(include='number').columns

# Calculate statistics only for numeric columns
Data_Stat_All.loc[numeric_cols, 'median'] = Numeric_DataFrame[numeric_cols].median()
Data_Stat_All.loc[numeric_cols, 'mode'] = Numeric_DataFrame[numeric_cols].mode().iloc[0]
Data_Stat_All.loc[numeric_cols, 'std'] = Numeric_DataFrame[numeric_cols].std()

# Fill NaN for non-numeric data types with 'N/A'
Data_Stat_All.fillna('N/A', inplace=True)

# Display the updated statistics summary for all data types
print('-------------------------------------------------------------------------------')
print('Data Summary for All Data Types')
print('-------------------------------------------------------------------------------')
print(Data_Stat_All)
print('-------------------------------------------------------------------------------')

#%%

# Calculate and display the minimum and maximum values for each column
min_values = Numeric_DataFrame.min()
max_values = Numeric_DataFrame.max()

# Combine the results into a single DataFrame for easy display
min_max_df = pd.DataFrame({
    'Minimum': min_values,
    'Maximum': max_values
})

# Calculate the standard deviation for each column
std_values = Numeric_DataFrame.std(numeric_only=True)

# Display the standard deviation values
std_df = pd.DataFrame({'Standard Deviation': std_values})


# Display the minimum and maximum values
print('-------------------------------------------------------------------------------')
print('Minimum and Maximum Values for Each Column')
print('-------------------------------------------------------------------------------')
print(min_max_df)
print('-------------------------------------------------------------------------------')
print('Standard Deviation for Each Column')
print(std_df)
#%%
# ========================================
# EDA Univariate Analysis
# ========================================

#Correlation
import seaborn as sns
import matplotlib.pyplot as plt
 
# Select the target variable
target_variable = 'default.payment.next.month'

# Calculate the correlation of the target variable with other variables
correlation_with_target = Numeric_DataFrame.corr()[target_variable].drop(target_variable)

# Sort the correlations in descending order
correlation_with_target_sorted = correlation_with_target.sort_values(ascending=False)

# Plot the correlation of the target variable with other variables
plt.figure(figsize=(10, 6))
sns.barplot(x=correlation_with_target_sorted.values, y=correlation_with_target_sorted.index, palette='coolwarm')
plt.title('Correlation of {} with Other Variables'.format(target_variable))
plt.xlabel('Correlation Coefficient')
plt.ylabel('Variable')
plt.show()

#%%
# ----------------------------------------
# Plotting the histogram of attributes
# ----------------------------------------
#histograms of PAY_ variable 
# Import the package

columns = Numeric_DataFrame.columns
# Set the number of rows and columns for subplots
num_rows = 2
num_cols = 3
# Create a new figure and set its size
plt.figure(figsize=(20, 20))

# Exclude specified columns
columns_to_exclude = ['ID','LIMIT_BAL','SEX', 'EDUCATION', 'MARRIAGE','AGE','BILL_AMT1','BILL_AMT2','BILL_AMT3','BILL_AMT4','BILL_AMT5','BILL_AMT6','PAY_AMT1','PAY_AMT2','PAY_AMT3','PAY_AMT4','PAY_AMT5','PAY_AMT6', 'default.payment.next.month']
columns_to_plot = [col for col in Numeric_DataFrame.columns if col not in columns_to_exclude]

for i, column in enumerate(columns_to_plot):
    plt.subplot(num_rows, num_cols, i + 1)
    plt.hist(Numeric_DataFrame[column].dropna(), bins=30, edgecolor='black')
    plt.title(column)

# Add a title to the whole figure
plt.suptitle('Histograms of PAY Variables', fontsize=20)    
# Adjust layout
plt.tight_layout()
# Show the plot
plt.show()
#%%
#histograms of BILL_AMOUNT variable
# Set the number of rows and columns for subplots
num_rows = 2
num_cols = 3
# Create a new figure and set its size
plt.figure(figsize=(20, 20))

# Exclude specified columns
columns_to_exclude = ['ID','LIMIT_BAL','SEX', 'EDUCATION', 'MARRIAGE','AGE','PAY_0','PAY_2','PAY_3','PAY_4','PAY_5','PAY_6','PAY_AMT1','PAY_AMT2','PAY_AMT3','PAY_AMT4','PAY_AMT5','PAY_AMT6', 'default.payment.next.month']
columns_to_plot = [col for col in Numeric_DataFrame.columns if col not in columns_to_exclude]

for i, column in enumerate(columns_to_plot):
    plt.subplot(num_rows, num_cols, i + 1)
    plt.hist(Numeric_DataFrame[column].dropna(), bins=30, edgecolor='black')
    plt.title(column)

# Add a title to the whole figure
plt.suptitle('Histograms of BILL_AMOUNT Variables', fontsize=20)
# Adjust layout
plt.tight_layout()
# Show the plot
plt.show()
#%%
#histograms of PAY_AMOUNT variable
# Set the number of rows and columns for subplots
num_rows = 2
num_cols = 3
# Create a new figure and set its size
plt.figure(figsize=(20, 20))

# Exclude specified columns
columns_to_exclude = ['ID','LIMIT_BAL','SEX', 'EDUCATION', 'MARRIAGE','AGE','PAY_0','PAY_2','PAY_3','PAY_4','PAY_5','PAY_6','BILL_AMT1','BILL_AMT2','BILL_AMT3','BILL_AMT4','BILL_AMT5','BILL_AMT6', 'default.payment.next.month']
columns_to_plot = [col for col in Numeric_DataFrame.columns if col not in columns_to_exclude]

for i, column in enumerate(columns_to_plot):
    plt.subplot(num_rows, num_cols, i + 1)
    plt.hist(Numeric_DataFrame[column].dropna(), bins=30, edgecolor='black')
    plt.title(column)

# Add a title to the whole figure
plt.suptitle('Histograms of PAY_AMOUNT Variables', fontsize=20)
# Adjust layout
plt.tight_layout()
# Show the plot
plt.show()
#%%
#histograms of LIMIT_BAL variable

# Separate defaulters and non-defaulters
defaulters = Numeric_DataFrame[Numeric_DataFrame['default.payment.next.month'] == 1]
non_defaulters = Numeric_DataFrame[Numeric_DataFrame['default.payment.next.month'] == 0]

plt.figure(figsize=(12, 7))

# Plot the histogram for all customers
plt.hist(Numeric_DataFrame['LIMIT_BAL'].dropna(), bins=30, edgecolor='black', alpha=0.6, label='All Customers')

# Plot the histogram for defaulters
plt.hist(defaulters['LIMIT_BAL'].dropna(), bins=30, edgecolor='red', alpha=0.6, label='Defaulters')

# Adding labels and title
plt.title('Histogram of LIMIT_BAL Variable with Defaulters')
plt.xlabel('LIMIT_BAL')
plt.ylabel('Frequency')
plt.xticks(ticks=range(0, int(Numeric_DataFrame['LIMIT_BAL'].max()) + 1, 100000), labels=range(0, int(Numeric_DataFrame['LIMIT_BAL'].max()) + 1, 100000))
plt.legend()

# Show the plot
plt.show()
#%%
# ----------------------------------------
# Plotting the bargraph 
# ----------------------------------------
#Bar graph of SEX variable
# Rename the class for the SEX column
Numeric_DataFrame['SEX'] = Numeric_DataFrame['SEX'].map({1: 'Male', 2: 'Female'})

# Calculate the counts of each category
total_counts = Numeric_DataFrame['SEX'].value_counts()

# Calculate the counts of defaulters in each category
defaulter_counts = Numeric_DataFrame[Numeric_DataFrame['default.payment.next.month'] == 1]['SEX'].value_counts()

# Calculate non-defaulter counts
non_defaulter_counts = total_counts - defaulter_counts

# Plot the bar graph with same colors for both genders
plt.figure(figsize=(10, 6))

# Plot defaulters (bottom part of the bars)
defaulter_counts.plot(kind='bar', color='red', edgecolor='black', label='Defaulters')

# Plot non-defaulters (top part of the bars)
non_defaulter_counts.plot(kind='bar', color='blue', edgecolor='black', label='Non-Defaulters', bottom=defaulter_counts)

# Adding labels and title
plt.title('Frequency of Data Points by SEX with Defaulters at the Bottom')
plt.xlabel('SEX')
plt.ylabel('Frequency')
plt.xticks(rotation=0)

# Adding legend
plt.legend()

# Show the plot
plt.show()
#%%
#bar graph of marital status
# Rename the categories
marital_status = {0: 'Unknown', 1: 'Married', 2: 'Single', 3: 'Others'}
Numeric_DataFrame['MARRIAGE'] = Numeric_DataFrame['MARRIAGE'].map(marital_status)

# Count the frequency of each category
total_counts = Numeric_DataFrame['MARRIAGE'].value_counts()

# Count the frequency of defaulters in each category
defaulter_counts = Numeric_DataFrame[Numeric_DataFrame['default.payment.next.month'] == 1]['MARRIAGE'].value_counts()

# Calculate non-defaulter counts
non_defaulter_counts = total_counts - defaulter_counts

# Plot the bar graph with defaulters at the bottom
plt.figure(figsize=(10, 6))

# Plot defaulters (bottom part of the bars)
defaulter_counts.plot(kind='bar', color='red', edgecolor='black', label='Defaulters')

# Plot non-defaulters (top part of the bars)
non_defaulter_counts.plot(kind='bar', color='blue', edgecolor='black', label='Non-Defaulters', bottom=defaulter_counts)

# Adding labels and title
plt.title('Frequency of Data Points by Marital Status with Defaulters')
plt.xlabel('Marital Status')
plt.ylabel('Frequency')
plt.xticks(rotation=0)

# Adding legend
plt.legend()

# Show the plot
plt.show()

#%%
# Rename the categories and merge 0, 5, 6 as 'Unknown'
education_status = {1: 'Graduate School', 2: 'University', 3: 'High School', 4: 'Others', 0: 'Unknown', 5: 'Unknown', 6: 'Unknown'}
Numeric_DataFrame['EDUCATION'] = Numeric_DataFrame['EDUCATION'].map(education_status)

# Count the frequency of each category
total_counts = Numeric_DataFrame['EDUCATION'].value_counts()

# Count the frequency of defaulters in each category
defaulter_counts = Numeric_DataFrame[Numeric_DataFrame['default.payment.next.month'] == 1]['EDUCATION'].value_counts()

# Calculate non-defaulter counts
non_defaulter_counts = total_counts - defaulter_counts

# Plot the bar graph with defaulters at the bottom
plt.figure(figsize=(10, 6))

# Plot defaulters (bottom part of the bars)
defaulter_counts.plot(kind='bar', color='red', edgecolor='black', label='Defaulters')

# Plot non-defaulters (top part of the bars)
non_defaulter_counts.plot(kind='bar', color='skyblue', edgecolor='black', label='Non-Defaulters', bottom=defaulter_counts)

# Adding labels and title
plt.title('Frequency of Data Points by Education Level with Defaulters')
plt.xlabel('Education Level')
plt.ylabel('Frequency')
plt.xticks(rotation=0)

# Adding legend
plt.legend()

# Show the plot
plt.show()

#%%
#Histogram for AGE variable
# Plot the histogram
plt.figure(figsize=(10, 6))
plt.hist(Numeric_DataFrame['AGE'], bins=10, color='skyblue', edgecolor='black')
plt.title('Distribution of Age')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.show()

#%%
#Bar graph of MARRIAGE-LIMIT_BAL
# Group data by Marriage and calculate the average Limit Balance
grouped_data = Numeric_DataFrame.groupby('MARRIAGE')['LIMIT_BAL'].mean().reset_index()

# Plotting the bar chart
plt.figure(figsize=(10, 6))
plt.bar(grouped_data['MARRIAGE'], grouped_data['LIMIT_BAL'], color='skyblue')
plt.xlabel('Marriage')
plt.ylabel('Limit Balance')
plt.title('Average Limit Balance by Marital Status')
plt.xticks(rotation=45)
plt.show()

#%%
#Bar graph of EDUCATION-LIMIT_BAL
# Group data by Education and calculate the average Limit Balance
grouped_data = Numeric_DataFrame.groupby('EDUCATION')['LIMIT_BAL'].mean().reset_index()

# Plotting the bar chart
plt.figure(figsize=(10, 6))
plt.bar(grouped_data['EDUCATION'], grouped_data['LIMIT_BAL'], color='skyblue')
plt.xlabel('Education')
plt.ylabel('Limit Balance')
plt.title('Average Limit Balance by Education')
plt.xticks(rotation=45)
plt.show()

#%%

#Piechart of target class distribution
# Calculate the percentage of each category
default_counts = Numeric_DataFrame['default.payment.next.month'].value_counts(normalize=True) * 100
default_counts = default_counts.rename(index={0: 'No', 1: 'Yes'})

# Plotting the pie chart
plt.figure(figsize=(8, 8))
plt.pie(default_counts, labels=default_counts.index, autopct='%1.1f%%', startangle=140, colors=['lightblue', 'lightcoral'])
plt.title('Target Class Distribution')
plt.legend(default_counts.index, title="Default Payment", loc="upper right")
plt.show()

#%%
#drop ID column
Numeric_DataFrame = Numeric_DataFrame.drop(columns='ID')
#Train and Test data split
#Randomly select 7500 entries from the dataset for testing
X_test = Numeric_DataFrame.sample(n=7500, random_state=42)
# Remove the randomly selected entries from the original dataset
X_train = Numeric_DataFrame.drop(X_test.index)

#%%
#correct the index value of test data
X_test.reset_index(drop=True, inplace=True)
#%%
# ========================================
# Class Distribution of training data
# ========================================
print("-----------------------------------------------")
print("Class Distribution of training data")
print("-----------------------------------------------")
class_distribution = X_train['default.payment.next.month'].value_counts(normalize=True) * 100
print("Class - 0: {:.3f}%".format(class_distribution[0]))
print("Class - 1: {:.3f}%".format(class_distribution[1]))

#%%
# Import the package
import numpy as np
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, f1_score,classification_report
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

# Ensure all columns are numeric (this is more for safety, as the columns appear to be numeric already)
numeric_df = Numeric_DataFrame.apply(pd.to_numeric, errors='coerce')

# Separate features and target variable from the DataFrame
Features_train = X_train.drop(['default.payment.next.month'], axis=1)  # Dropping the target variable to keep only features
Labels_train = X_train['default.payment.next.month']  # Selecting only the target variable

# Check for any NaN values that might have resulted from coercion
nan_check = Features_train.isna().sum()
# Print the results
print("NaN values in each column after coercion:")
print(nan_check)
# Replace NaN values with a placeholder (-999)
Features_train.replace(np.nan, -999, inplace=True)

# #-------------------------------
# # Feature normalisation 
# #-------------------------------
# # Initialize the MinMaxScaler
scaler = MinMaxScaler()
# # Fit and transform the DataFrame
Features_train = pd.DataFrame(scaler.fit_transform(Features_train), columns=Features_train.columns)
#%%

# Random Forest
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(Features_train, Labels_train)

# XGBoost
xgb_model = XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42)
xgb_model.fit(Features_train, Labels_train)

# Logistic Regression
lr_model = LogisticRegression(random_state=42, max_iter=1000)
lr_model.fit(Features_train, Labels_train)

# Decision Tree
dt_model = DecisionTreeClassifier(random_state=42)
dt_model.fit(Features_train, Labels_train)
#%%
# Evaluate Models on Training Data
print("\nTraining Data Evaluation:\n")
# Evaluate Models on Training Data
train_results = []
for name, model in zip(['Random Forest', 'XGBoost', 'Logistic Regression', 'Decision Tree'], [rf_model, xgb_model, lr_model, dt_model]):
    y_train_pred = model.predict(Features_train)
    accuracy = accuracy_score(Labels_train, y_train_pred)
    precision = precision_score(Labels_train, y_train_pred)
    recall = recall_score(Labels_train, y_train_pred)
    f1 = f1_score(Labels_train, y_train_pred)
    roc_auc = roc_auc_score(Labels_train, model.predict_proba(Features_train)[:, 1])
    train_results.append([name, accuracy, precision, recall, f1, roc_auc])
# Create a DataFrame for training results
train_results_df = pd.DataFrame(train_results, columns=['Model', 'Accuracy', 'Precision', 'Recall', 'F1-Score', 'ROC-AUC'])

print("\nTraining Data Evaluation:\n")
print(train_results_df)
#%%
# Evaluate Models on Test Data
# Separate features and target variable from the DataFrame
Features_test = X_test.drop(['default.payment.next.month'], axis=1)  # Dropping the target variable to keep only features
Labels_test = X_test['default.payment.next.month']  # Selecting only the target variable

# #-------------------------------
# # Feature normalisation 
# #-------------------------------
# # Initialize the MinMaxScaler
scaler = MinMaxScaler()
# # Fit and transform the DataFrame
Features_test = pd.DataFrame(scaler.fit_transform(Features_test), columns=Features_test.columns)
#%%
#imports for confusion matrix
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

test_results = []

# Loop through each model
for name, model in zip(['Random Forest', 'XGBoost', 'Logistic Regression', 'Decision Tree'], 
                       [rf_model, xgb_model, lr_model, dt_model]):
    # Predict on the test data
    y_test_pred = model.predict(Features_test)
    
    # Calculate evaluation metrics
    accuracy = accuracy_score(Labels_test, y_test_pred)
    precision = precision_score(Labels_test, y_test_pred)
    recall = recall_score(Labels_test, y_test_pred)
    f1 = f1_score(Labels_test, y_test_pred)
    roc_auc = roc_auc_score(Labels_test, model.predict_proba(Features_test)[:, 1])
    
    # Append the results to the test_results list
    test_results.append([name, accuracy, precision, recall, f1, roc_auc])
    
    # Calculate and plot the confusion matrix
    cm = confusion_matrix(Labels_test, y_test_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm)
    disp.plot(cmap=plt.cm.Blues)  # You can customize the colormap if desired
    plt.title(f'{name} Confusion Matrix')
    plt.show()
    
# Create a DataFrame for test results
test_results_df = pd.DataFrame(test_results, columns=['Model', 'Accuracy', 'Precision', 'Recall', 'F1-Score', 'ROC-AUC'])

print("\nTest Data Evaluation:\n")
print(test_results_df)
#%%
#Develop Hybrid Model: Averaging predictions
#evaluation on traindata
y_pred_rf_train = rf_model.predict_proba(Features_train)[:, 1]
y_pred_xgb_train = xgb_model.predict_proba(Features_train)[:, 1]
y_pred_lr_train = lr_model.predict_proba(Features_train)[:, 1]
y_pred_dt_train = dt_model.predict_proba(Features_train)[:, 1]

# Averaging predictions for training data
y_pred_hybrid_train = (y_pred_rf_train + y_pred_xgb_train + y_pred_lr_train + y_pred_dt_train) / 4
y_pred_hybrid_label_train = (y_pred_hybrid_train >= 0.5).astype(int)

# Hybrid Model Evaluation on Training Data
hybrid_accuracy_train = accuracy_score(Labels_train, y_pred_hybrid_label_train)
hybrid_precision_train = precision_score(Labels_train, y_pred_hybrid_label_train)
hybrid_recall_train = recall_score(Labels_train, y_pred_hybrid_label_train)
hybrid_f1_train = f1_score(Labels_train, y_pred_hybrid_label_train)
hybrid_roc_auc_train = roc_auc_score(Labels_train, y_pred_hybrid_train)

# Display Hybrid Model Evaluation on Training Data
hybrid_results_train_df = pd.DataFrame([['Hybrid Model (Train)', hybrid_accuracy_train, hybrid_precision_train, hybrid_recall_train, hybrid_f1_train, hybrid_roc_auc_train]],
                                       columns=['Model', 'Accuracy', 'Precision', 'Recall', 'F1-Score', 'ROC-AUC'])

print("\nHybrid Model Evaluation on Training Data:\n")
print(hybrid_results_train_df)

#%%
#Develop Hybrid Model: Averaging predictions
#evaluation on testdata
y_pred_rf = rf_model.predict_proba(Features_test)[:, 1]
y_pred_xgb = xgb_model.predict_proba(Features_test)[:, 1]
y_pred_lr = lr_model.predict_proba(Features_test)[:, 1]
y_pred_dt = dt_model.predict_proba(Features_test)[:, 1]

# Averaging predictions
y_pred_hybrid = (y_pred_rf + y_pred_xgb + y_pred_lr + y_pred_dt) / 4
y_pred_hybrid_label = (y_pred_hybrid >= 0.5).astype(int)

# Hybrid Model Evaluation
hybrid_accuracy = accuracy_score(Labels_test, y_pred_hybrid_label)
hybrid_precision = precision_score(Labels_test, y_pred_hybrid_label)
hybrid_recall = recall_score(Labels_test, y_pred_hybrid_label)
hybrid_f1 = f1_score(Labels_test, y_pred_hybrid_label)
hybrid_roc_auc = roc_auc_score(Labels_test, y_pred_hybrid)

# Display Hybrid Model Evaluation
hybrid_results_df = pd.DataFrame([['Hybrid Model (Test)', hybrid_accuracy, hybrid_precision, hybrid_recall, hybrid_f1, hybrid_roc_auc]],columns=['Model', 'Accuracy', 'Precision', 'Recall', 'F1-Score', 'ROC-AUC'])

print("\nHybrid Model Evaluation on Test Data:\n")
print(hybrid_results_df)

# Calculate the confusion matrix for testdata on hybrid model
hybrid_cm = confusion_matrix(Labels_test, y_pred_hybrid_label)
ConfusionMatrixDisplay(confusion_matrix=hybrid_cm).plot()
plt.title('Hybrid Model Confusion Matrix')
plt.show()
#%%
from sklearn.inspection import permutation_importance

# For Random Forest model
rf_importance = permutation_importance(rf_model, Features_test, Labels_test, n_repeats=10, random_state=42)
rf_sorted_idx = rf_importance.importances_mean.argsort()

# Print out the importance
print("Random Forest Permutation Feature Importance:")
for i in rf_sorted_idx[::-1]:  # Reverse order for descending importance
    print(f"{X_test.columns[i]}: {rf_importance.importances_mean[i]:.4f}")

#%%
# Sort the features and their importance in descending order
sorted_importance = rf_importance.importances_mean[rf_sorted_idx[::-1]]
sorted_features = X_test.columns[rf_sorted_idx[::-1]]

# Plot the bar chart
plt.figure(figsize=(10, 6))
plt.barh(sorted_features, sorted_importance, color='blue')
plt.xlabel('Importance')
plt.ylabel('Feature')
plt.title('Random Forest Permutation Feature Importance')
plt.gca().invert_yaxis()  # To display the highest importance at the top
plt.show()
#%%
# For XGBoost model
xgb_importance = permutation_importance(xgb_model, Features_test, Labels_test, n_repeats=10, random_state=42)
xgb_sorted_idx = xgb_importance.importances_mean.argsort()

# Print out the importance
print("XGBoost model Permutation Feature Importance:")
for i in xgb_sorted_idx[::-1]:  # Reverse order for descending importance
    print(f"{X_test.columns[i]}: {xgb_importance.importances_mean[i]:.4f}")

#%%
# Sort the features and their importance in descending order
sorted_importance = xgb_importance.importances_mean[xgb_sorted_idx[::-1]]
sorted_features = X_test.columns[xgb_sorted_idx[::-1]]

# Plot the bar chart
plt.figure(figsize=(10, 6))
plt.barh(sorted_features, sorted_importance, color='blue')
plt.xlabel('Importance')
plt.ylabel('Feature')
plt.title('XGBoost Model Permutation Feature Importance')
plt.gca().invert_yaxis()  # To display the highest importance at the top
plt.show()
#%%

